const register = () =>{
    return(
        <div>register</div>
    )
}

export default register;