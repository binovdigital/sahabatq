const login = () =>{
    return(
        <div>
            login
        </div>
    )
}

export default login;