const DashboardAdmin = () =>{
    return(
        <div>
            Dashboard admin
        </div>
    )
}
export default DashboardAdmin;