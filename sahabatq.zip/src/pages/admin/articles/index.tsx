const ArticlesComponent = () =>{
    return(
        <div>
            Dashboard admin
        </div>
    )
}
export default ArticlesComponent;