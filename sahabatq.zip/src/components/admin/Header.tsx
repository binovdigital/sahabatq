const HeaderAdmin = () =>{
    return(
        <div>
            header admin
        </div>
    )
}
export default HeaderAdmin