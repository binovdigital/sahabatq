import { Carousel } from "@material-tailwind/react";
import { ChevronLeftIcon, ChevronRightIcon, StarIcon } from '@heroicons/react/24/solid'


const ReviewComponent = () =>{
    return(
        <Carousel
        nextArrow={({handleNext})=>(
          <button onClick={()=>handleNext()} className="!absolute top-2/4 right-4 -translate-y-2/4 rounded-full select-none transition-all disabled:opacity-50 disabled:shadow-none disabled:pointer-events-none w-12 max-w-[48px] h-12 max-h-[48px] text-orange-600 hover:bg-white/10 active:bg-white/30 grid place-items-center">
            <ChevronRightIcon className="h-7 w-7" />
          </button>
        )}
        prevArrow={({handlePrev})=>(
          <button onClick={()=>handlePrev()} className="!absolute top-2/4 left-4 -translate-y-2/4 rounded-full select-none transition-all disabled:opacity-50 disabled:shadow-none disabled:pointer-events-none w-12 max-w-[48px] h-12 max-h-[48px] text-orange-600 hover:bg-white/10 active:bg-white/30 grid place-items-center">
            <ChevronLeftIcon className="h-7 w-7" />
          </button>
        )}
        navigation={({ setActiveIndex, activeIndex, length }) => (
          <div className="absolute bottom-4 left-2/4 z-2 flex -translate-x-2/4 gap-2">
            {new Array(length).fill("").map((_, i) => (
              <span
                key={i}
                className={`block h-2 cursor-pointer rounded-2xl transition-all content-[''] ${
                  activeIndex === i ? "w-4 bg-orange-600" : "w-2 bg-[#f2bda9]"
                }`}
                onClick={() => setActiveIndex(i)}
              />
            ))}
          </div>
        )}
        >
          <div className="flex flex-col items-center space-y-2 text-center py-6">
            <div className="flex items-center space-x-1">
              <StarIcon className="text-[#F4C779] w-4 h-4"></StarIcon>
              <StarIcon className="text-[#F4C779] w-4 h-4"></StarIcon>
              <StarIcon className="text-[#F4C779] w-4 h-4"></StarIcon>
            </div>
          </div>
      </Carousel>
    )
}
export default ReviewComponent;